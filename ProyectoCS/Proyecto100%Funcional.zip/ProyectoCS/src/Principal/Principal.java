package Principal;

import Vista.frmMenu;

/**
 *
 * @author Usuario
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        frmMenu frm = new frmMenu();

        frm.setVisible(true);
    }

}
